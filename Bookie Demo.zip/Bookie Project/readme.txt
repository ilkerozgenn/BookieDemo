Project Group: G3E

Title: Project "Bookie" Final Code

Description: Bookie is planned to be desktop application to exchange second-hand textbooks. 
Inside the application, users will post a textbook and wait for a buyer in their local area 
to reach them. After the seller has been contacted, they can decide on a price, and a meeting 
place to trade the textbook. This application is designed to benefit both active students and 
alumni since people will earn money by selling books they do not use anymore and buy the books 
they need for a cheaper price. 

Status: The application is over. It compiles and runs successfully. There isn't any problem except some bugs. 

Code Organization: Firstly, the model classes like User and Listing class are coded. Then, these classes were put 
together and made compatible with each other. Secondly, the view classes are designed in Netbeans IDE, using 
Java's Swing and AWT libraries. Then, the source code of the components were taken from Netbeans IDE and implemented 
in seperate classes using VS Code and IntelliJ Idea. Thirdly, the test classes and controller classes for these UI files were implemented.
Lastly, all of these classes were put together and made arrangements so that they can interact between each other. 
After debugging, a demo class was implemented and tested.

Tools That Are Used: 
	- Netbeans IDE 8.2
	- Visual Studio Code 15.0.1
	- IntelliJ Idea 2020.3.2
	- Java Swing Library	
	- Java AWT Library
	* Another library except Swing and AWT is not used in this application.
	* A library or another tool is not used for a database.	

Instructions: 
	1. Unzip the folder to a suitable place in the computer.
	2. Open any Java IDE and open the project in it.
	3. Click on src folder and open BookieDemo.java file.
	4. Right-click on the code and click "run".
	5. Now, the demo of the application should be running successfully.

Contributions:
	1. İlker Özgen
		- implemented Status class
		- implemented the user-interface of Login Page
		- implemented the user-interface of Sign Up Page
		- implemented the user-interface of Forgot Password Page
		- implemented the user-interface of Set New Password Page
		- contributed to the implementation of the user-interface of Main Page
		- contributed to the implementation if the user-interface of Toolbar
		- implemented the test classes of specified user-interfaces above
		- implemented the controller class of Login Page
		- implemented the controller class of Sign Up Page
		- implemented the controller class of Forgot Password Page
		- implemented the controller class of Set New Password Page
		- contributed to the implementation of the demo class
		- helped other team members when they are stuck at a bug or another issue
	
	2. Onurcan Ataç
		- implemented the Listing class
		- implemented the user-interface of Setting Page 
		- implemented the user-interface of Post Item Page
		- implemented the test classes of the specified user-interfaces above
		- contributed to the implementation of the user-interface of Main Page
		- contributed to the implementation of the user-interface of Toolbar
		- implemented the controller class of toolbar
		- implemented the controller class of Settings Page
		- implemented the controller class of Post Item Page
		- contributed to the implementation of the controller class of Main Page
		- contributed to the implementation of the demo class
		- helped other team members when they are stuck at a bug or at another issue

	3. Bora Yılmaz
		- implemented Location class
		- implemented the test class of Location class
		- contributed to the implementation of User class
		- contributed to the implementation of the user-interface of Main Page
		- implemented the user-interface of Listing Page 
		- implemented the user-interface of User Profile Page
		- implemented the test classes of specified user-interfaces above
		- contributed to the implementation of the controller class of Main Page
		- implemented the controller class of User Profile Page
		- contributed to the implementation if the user-interface of Toolbar
		- contributed to the implementation of the demo class
		- revised the model classes
		- helped other team members when they are stuck at a bug or at another issue

	4. Selimhan Tokat
		- implemented Course class
	
	5. Arda Baktır
		- contributed to the implementation of User class


